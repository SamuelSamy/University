class ClientValidator:
    # TODO Implement

    def validate(self, client):
        return True
